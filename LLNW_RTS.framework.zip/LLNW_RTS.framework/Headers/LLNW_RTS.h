//
//  LLNW_RTS.h
//  LLNW RTS
//
//  Created by Ted Klingenberg on 11/19/20.
//

#import <Foundation/Foundation.h>

//! Project version number for LLNW_RTS.
FOUNDATION_EXPORT double LLNW_RTSVersionNumber;

//! Project version string for LLNW_RTS.
FOUNDATION_EXPORT const unsigned char LLNW_RTSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LLNW_RTS/PublicHeader.h>


